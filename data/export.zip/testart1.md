With wildcard domains it’s important to make sure your DNS provider configuration agrees with Heroku. In particular, if you have configured your DNS for *.example.com to point to example.herokuapp.com, be sure you also run heroku domains:add *.example.com. Otherwise, a malicious person could add baddomain.example.com to their Heroku app and receive traffic intended for your application.

